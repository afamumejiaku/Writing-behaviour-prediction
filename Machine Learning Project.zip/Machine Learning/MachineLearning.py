# -*- coding: utf-8 -*-
"""
Created on Wed May  6 09:55:46 2020

@author: Afam
"""

from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.naive_bayes import GaussianNB
from sklearn.datasets import load_digits
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sn
import pandas as pd

file = input("Please enter name of file to Analyse : ")
data = pd.read_csv(file)

print("This program analysis the Behaviorial characteristics using Age and Sex")
print("For Age type Age, for Age and Sex type both")
Question  = input("please enter what you would like to analyse at the prompt :")
Input = Question.lower()
if Input == 'age':
    print("Determining Behaviour using Age")
    X = data.drop(['Age','ID'], axis=1)
    Y = data['Age']
else:
    print("Unknown entered hence determining Behaviour using Sex and Age")
    X = data.drop(['Age','Gender','ID'], axis=1)
    Y = data['Age']


X_train, X_test,y_train,y_test = train_test_split(X,Y,test_size=0.3,random_state = 3)
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.fit_transform(X_test)


#developing Models
model_params = {
        'Naives_Bayes':{'model':GaussianNB(),'params': {}},
        'svm':{'model': SVC(), 'params': {'gamma':['auto','scale'],'C':[1,10,20], 'kernel':['rbf','linear']}},
        'random_forest' : {'model' : RandomForestClassifier(), 'params':{'n_estimators':[1,5,10]}},
        'logistic_regression':{'model': LogisticRegression(), 'params': {'solver':['liblinear'],'multi_class':['auto','ovr'],'C':[1,5,10]}},
        }
results = []
for model_name, mp in model_params.items():
    Model = GridSearchCV(mp['model'], mp['params'], cv=2, return_train_score=False)
    Model.fit(X_train, y_train)
    results.append({'model': model_name, "best_score": Model.best_score_, 'best_params': Model.best_params_})
    # ModelSelected = Model.predict

print("\n Analysing the best machine learning algoritm to use :")

print("\n Best results for all tried Algoritms showing their parameters are: ")
df =pd.DataFrame(results, columns=['model', "best_score", 'best_params'])
print(df)

bestScore = 0
for score in results:
    Score = score["best_score"]
    if Score > bestScore:
        bestScore = Score
        bestModel = score["model"]
        bestParameters = score["best_params"]

print("The Best Machine learning Algoritm here is " + str(bestModel) + " using these parameters " + str(bestParameters) + "and has a Score(The mean accuracy on the given test data and labels) of " + str(bestScore)+ "\n")
if bestModel == 'svm':
    print("Using SVM for the Machine learning")
    Model = SVC(C = bestParameters['C'], gamma= bestParameters['gamma'], kernel= bestParameters['kernel'])
elif bestModel == 'Naives_Bayes':
    print("Using Naives_Bayes for the Machine learning")
    Model = GaussianNB()
elif bestModel == 'random_forest':
    print("Using random_forest for the Machine learning")
    Model = RandomForestClassifier(n_estimators = bestParameters['n_estimators'])
else:
    print("Using Logistic Regression for the Machine learning")
    Model = LogisticRegression(solver= bestParameters['solver'], multi_class = bestParameters['multi_class'],C = bestParameters['C'] )

Model.fit(X_train, y_train)
print("The  Score(The mean accuracy on the given test data and labels) here is : ", Model.score(X_test,y_test))
y_predicted = Model.predict(X_test)
cm= confusion_matrix(y_test, y_predicted)
plt.figure(figsize=(10,10))
plt.plot(y_predicted,y_test,color = "red", label = "plot")
plt.scatter(y_predicted,y_test,color = "blue", label = "Scatter")
plt.legend()
plt.title("Graph")
#sn.heatmap(cm, annot=True)
plt.xlabel("Predicted")
plt.ylabel("Truth")