# -*- coding: utf-8 -*-
"""                                                
Created on Mon Apr 20 12:29:33 2020

@author: Afam
"""
import csv            
import statistics     
import glob             

Rowsize  = int(input("please enter the number of row from each file to occupy: ")) 
Filename = input("\n Please enter the name you would like to name the output file created: ")

def main(Filename):
    #Reading all files in the folder
    fileList = glob.glob("data*.csv")    
    main_file =[]
    count  = 0
    for filenames in fileList:                   
        lines = [] 
        count = count + 1
        with open(filenames, 'r') as csvfile:      
            csvreader = csv.reader(csvfile)
            for line in csvreader:                   
                lines.append(line)
    #Creating Features
        files = createFeatures(lines, count)  
        main_file.extend(files[1])  
    #Saving the files as a CSV named Features    
    filename = Filename       # name of csv file 
    # writing to csv file 
    with open(filename, 'w', newline='') as csvfile:     # creating a csv writer object 
        csvwriter = csv.writer(csvfile)    
        csvwriter.writerow(files[0])     # writing the fields names
        csvwriter.writerows(main_file)   # writing the data rows

#Function to create Features
def createFeatures(lines, count):  
    file = []
    for i in range(len(lines)):
        column = []
        for j in range(len(lines[i])):
            column.append(0)
        file.append(column)
#Transfering the data read to the 2D Array 
    for i in range(1,len(lines)):
        for j in range(len(lines[i])):
            k=i-1
            if j < 3:
                file[k][j]=int(lines[i][j])
            else:
                file[k][j]=float(lines[i][j])
#
    ArraySize = int((len(file)-1)/Rowsize)
    print("Compressed by %2d rows, File no %2d" %(ArraySize, count))
    ID = []
    Gender = []
    Age = []
    AccX = []
    AccY = []
    AccZ = []
    GyroX = []
    GyroY = []
    GyroZ = []
    for i in range(Rowsize):
        subID = []
        subGender = []
        subAge = []
        subAccX = []
        subAccY = []
        subAccZ = []
        subGyroX = []
        subGyroY = []
        subGyroZ = []
        for j in range(ArraySize):
            k = (j + (i*ArraySize))
            subID.append(file[k][0])
            subGender.append(file[k][1])
            subAge.append(file[k][2])
            subAccX.append(file[k][3])
            subAccY.append(file[k][4])
            subAccZ.append(file[k][5])
            subGyroX.append(file[k][6])
            subGyroY.append(file[k][7])
            subGyroZ.append(file[k][8])
        ID.append(subID)
        Gender.append(subGender)
        Age.append(subAge)
        AccX.append(subAccX)
        AccY.append(subAccY)
        AccZ.append(subAccZ)
        GyroX.append(subGyroX)
        GyroY.append(subGyroY)
        GyroZ.append(subGyroZ)
    data = [ID,Gender,Age,AccX,AccY,AccZ,GyroX,GyroY,GyroZ]
    Data = ["ID","Gender","Age","AccX","AccY","AccZ","GyroX","GyroY","GyroZ"]
    Variables = ["Median","Mean", "Mode","Stdev","Variance","SignChangeCount","Max","Min","Spread","Change","AbsoluteChange"]
    Median=[]
    Mean=[]
    Mode = []
    Stdev=[]
    Variance=[]
    SignChangeCount=[]  # Count number of times signs changed (Crosses Zero)
    Maximum = []
    Minimum = []
    Spread=[]  
    Change = []
    AbsoluteChange = []
    for i in range(len(Data)):
        subMedian = []
        subMean = []
        subMode = []
        subStdev = []
        subVariance = []
        SignCountChange = []
        subSpread = []
        subMax = []
        subMin = []
        subChange = []
        subAbsoluteChange = []
        for j in range(Rowsize):
            medians = statistics.median(data[i][j])
            subMedian.append(medians)
            means = statistics.mean(data[i][j])
            subMean.append(means)
            modes = getMode(data[i][j])
            subMode.append(modes)
            stdevs = statistics.stdev(data[i][j])
            subStdev.append(stdevs)
            variances = statistics.variance(data[i][j])
            subVariance.append(variances)
            SignCountChanges = SignCount(data[i][j])
            SignCountChange.append(SignCountChanges)
            submax = max(data[i][j])
            subMax.append(submax)
            submin = min(data[i][j])
            subMin.append(submin)
            subspread = submax - submin
            subSpread.append(subspread)
            change = getChange(data[i][j])
            subChange.append(change)
            abschange = getAbsoluteChange(data[i][j])
            subAbsoluteChange.append(abschange)
        Median.append(subMedian)
        Mean.append(subMean)
        Mode.append(subMode)
        Stdev.append(subStdev)    
        Variance.append(subVariance)    
        SignChangeCount.append(SignCountChange)
        Maximum.append(subMax)
        Minimum.append(subMin)
        Spread.append(subSpread)
        Change.append(subChange)
        AbsoluteChange.append(subAbsoluteChange)
    Features = []
    for i in range(Rowsize):
         FeaID = [Median[0][i]]
         FeaGender = [Median[1][i]]
         FeaAge = [Median[2][i]]
         FeaAccX = [Median[3][i],Mean[3][i],Mode[3][i],Stdev[3][i],Variance[3][i],SignChangeCount[3][i],Maximum[3][i],Minimum[3][i],Spread[3][i],Change[3][i],AbsoluteChange[3][i]]
         FeaAccY = [Median[4][i],Mean[4][i],Mode[4][i],Stdev[4][i],Variance[4][i],SignChangeCount[4][i],Maximum[4][i],Minimum[4][i],Spread[4][i],Change[4][i],AbsoluteChange[4][i]]
         FeaAccZ = [Median[5][i],Mean[5][i],Mode[5][i],Stdev[5][i],Variance[5][i],SignChangeCount[5][i],Maximum[5][i],Minimum[5][i],Spread[5][i],Change[5][i],AbsoluteChange[5][i]]
         FeaGyroX = [Median[6][i],Mean[6][i],Mode[6][i],Stdev[6][i],Variance[6][i],SignChangeCount[6][i],Maximum[6][i],Minimum[6][i],Spread[6][i],Change[6][i],AbsoluteChange[6][i]]
         FeaGyroY = [Median[7][i],Mean[7][i],Mode[7][i],Stdev[7][i],Variance[7][i],SignChangeCount[7][i],Maximum[7][i],Minimum[7][i],Spread[7][i],Change[7][i],AbsoluteChange[7][i]]
         FeaGyroZ = [Median[8][i],Mean[8][i],Mode[8][i],Stdev[8][i],Variance[8][i],SignChangeCount[8][i],Maximum[8][i],Minimum[8][i],Spread[8][i],Change[8][i],AbsoluteChange[8][i]]
         FeaData = FeaID + FeaGender + FeaAge + FeaAccX + FeaAccY + FeaAccZ + FeaGyroX + FeaGyroY + FeaGyroZ
         Features.append(FeaData)
    Featurenames = []
    for x in Data:
        for y in Variables:
            if x == "ID" or x == "Gender" or x == "Age":
                name =  x
                Featurenames.append(name)
                break
            else:
                name = y + " " + x
            Featurenames.append(name)
    return(Featurenames,Features)
  
# Function to Generate the count of number of time Zero is crossed      
def SignCount(array):
    Input = (array)
    prev = Input[0]
    count = 0
    for elem in Input:
        if elem == 0:
            sign = -1
        else:
            sign = elem / abs(elem)
        if sign == -prev:
            count = count + 1
        prev = sign
    return(count)

#Function to Generate the Mode. when no mode insert the mean.    
def getMode(nums):
    numsDict = {}
    max = 0
    mode = None
    for num in nums:
        if num not in numsDict:
            numsDict[num] = 1
        else:
            numsDict[num] += 1
        if max <= numsDict[num]:
            max = numsDict[num]
            mode = num
    if max > 1:
        return mode
    else:
        return (statistics.mean(nums))

def getAbsoluteChange(array):
    absChange = 0
    for value in array:
        x = abs(value)
        absChange = absChange + x
    return(absChange)
   
def getChange(array):
    Change = 0
    for value in array:
        Change = Change + value
    return(Change)


if __name__ == "__main__":
    main(Filename)